package stockTrader.client;

public class StockClient {
}
